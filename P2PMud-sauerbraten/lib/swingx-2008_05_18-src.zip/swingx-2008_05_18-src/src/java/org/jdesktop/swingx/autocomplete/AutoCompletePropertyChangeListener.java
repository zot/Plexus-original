/**
 * 
 */
package org.jdesktop.swingx.autocomplete;

import java.beans.PropertyChangeListener;

/**
 * @author Karl George Schaefer
 *
 */
public interface AutoCompletePropertyChangeListener extends
        PropertyChangeListener {

}
