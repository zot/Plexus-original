/**
 * Contains custom shapes for 2D rendering.
 */
package org.jdesktop.swingx.geom;

