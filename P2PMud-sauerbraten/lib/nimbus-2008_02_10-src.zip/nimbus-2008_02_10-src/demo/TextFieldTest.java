/*
* $Id: NimbusGraphicsUtils.java,v 1.9 2005/12/05 15:00:55 kizune Exp $
*
* Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
* Santa Clara, California 95054, U.S.A. All rights reserved.
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JPasswordField;
import javax.swing.JProgressBar;
import javax.swing.JSeparator;
import javax.swing.JSplitPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.WindowConstants;
import javax.swing.plaf.synth.SynthLookAndFeel;

import org.jdesktop.swingx.plaf.nimbus.NimbusGraphicsUtils;
import org.jdesktop.swingx.plaf.nimbus.NimbusLookAndFeel;

/**
 * TextFieldTest - Simple text field tests.
 * 
 * 
 * @author Created by Kevin Tew (Feb 9, 2007)
 * @version 1.0
 */
public class TextFieldTest {

    public static void main(String[] args) throws Exception {
        UIManager.setLookAndFeel(new NimbusLookAndFeel());

        JFrame frame = new JFrame("Nimbus Synth Test");
        JPanel topPanel = new JPanel();
        JPanel panel = new JPanel();
        JPanel panel1 = new JPanel();
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panel, panel1);
        topPanel.setLayout(new BoxLayout(topPanel,BoxLayout.Y_AXIS));
        topPanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        topPanel.add(splitPane);
        panel.setLayout(new FlowLayout());

        JTextField textField = new JTextField("Hello World");
        JTextArea textArea = new JTextArea("Hello World");
        JPasswordField passwordField = new JPasswordField("Hello World");
        panel.add(textField);
        panel.add(new JSeparator(SwingConstants.VERTICAL));
        panel.add(textArea);
        panel.add(new JSeparator(SwingConstants.VERTICAL));
        panel1.add(passwordField);

        frame.setBackground(NimbusGraphicsUtils.getWebColor("EBEDF2"));
        frame.getContentPane().setLayout(new BorderLayout());
        frame.getContentPane().add(topPanel,BorderLayout.CENTER);
        frame.pack();
        frame.setSize(400,200);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
