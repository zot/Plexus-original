/*
* $Id: NimbusGraphicsUtils.java,v 1.9 2005/12/05 15:00:55 kizune Exp $
*
* Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
* Santa Clara, California 95054, U.S.A. All rights reserved.
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.WindowConstants;
import javax.swing.plaf.synth.SynthLookAndFeel;

import org.jdesktop.swingx.plaf.nimbus.NimbusGraphicsUtils;

/**
 * SynthTest - Simple button and progressbar test class.
 *
 * @author Created by Jasper Potts (Jan 3, 2007)
 * @version 1.0
 */
public class SynthTest {

    public static void main(String[] args) throws Exception {
        SynthLookAndFeel synth = new SynthLookAndFeel();
        synth.load(NimbusGraphicsUtils.class.getResourceAsStream("nimbus.xml"), NimbusGraphicsUtils.class);
        UIManager.setLookAndFeel(synth);

        JFrame frame = new JFrame("Nimbus Synth Test");
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel,BoxLayout.Y_AXIS));
        topPanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        JPanel panel = new JPanel();
        topPanel.add(panel);
        panel.setLayout(new FlowLayout());

        JButton normal = new JButton("Cancel");
        panel.add(normal);
        JButton disabled = new JButton("Cancel");
        disabled.setEnabled(false);
        panel.add(disabled);
        JButton defaultBtn = new JButton("Cancel");
        panel.add(defaultBtn);
        frame.getRootPane().setDefaultButton(defaultBtn);

        JTextField textField = new JTextField("Hello World");
        panel.add(textField);

        JProgressBar progressBar = new JProgressBar(0,100);
        progressBar.setValue(50);
        topPanel.add(progressBar);
        topPanel.add(new JSeparator());

        JProgressBar progressBar100 = new JProgressBar(0,100);
        progressBar100.setValue(100);
        topPanel.add(progressBar100);
        topPanel.add(new JSeparator());

        JProgressBar intProgressBar = new JProgressBar(0,100);
        intProgressBar.setIndeterminate(true);
        topPanel.add(intProgressBar);

        frame.setBackground(NimbusGraphicsUtils.getWebColor("EBEDF2"));
        frame.getContentPane().setLayout(new BorderLayout());
        frame.getContentPane().add(topPanel,BorderLayout.CENTER);
        frame.pack();
        frame.setSize(400,200);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setVisible(true);

        for (Map.Entry<Object, Object> entry : UIManager.getLookAndFeelDefaults().entrySet()) {
            System.out.println(entry.getKey()+" = "+entry.getValue()+"  ["+entry.getValue().getClass().getName()+"]");
        }
        for (Map.Entry<Object, Object> entry : UIManager.getDefaults().entrySet()) {
            System.out.println(entry.getKey()+" = "+entry.getValue()+"  ["+entry.getValue().getClass().getName()+"]");
        }
    }
}
