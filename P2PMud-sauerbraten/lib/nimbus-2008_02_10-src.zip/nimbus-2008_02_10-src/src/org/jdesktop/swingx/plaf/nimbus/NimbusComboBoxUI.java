package org.jdesktop.swingx.plaf.nimbus;

import static org.jdesktop.swingx.plaf.nimbus.NimbusGraphicsUtils.loadImage;

import javax.swing.plaf.metal.MetalComboBoxUI;
import javax.swing.plaf.metal.MetalLookAndFeel;
import javax.swing.plaf.metal.MetalComboBoxButton;
import javax.swing.plaf.metal.MetalComboBoxIcon;
import javax.swing.plaf.metal.MetalBorders;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.UIResource;
import javax.swing.plaf.synth.SynthConstants;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.plaf.basic.BasicGraphicsUtils;
import javax.swing.plaf.basic.BasicComboBoxRenderer;
import javax.swing.plaf.basic.BasicComboBoxEditor;
import javax.swing.JComponent;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.ListCellRenderer;
import javax.swing.ComboBoxEditor;
import javax.swing.JTextField;
import javax.swing.border.Border;
import java.util.logging.Logger;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Color;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Container;
import java.awt.image.BufferedImage;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;

/**
 * NimbusComboBoxUI
 *
 * @author Created by Jasper Potts (Feb 1, 2007)
 * @version 1.0
 */
public class NimbusComboBoxUI extends BasicComboBoxUI implements MouseListener {
    private static final BufferedImage combo_normal = loadImage("combo_normal.png");
    private static final BufferedImage combo_over = loadImage("combo_over.png");
    private static final BufferedImage combo_pressed = loadImage("combo_pressed.png");
    private static final BufferedImage combo_disabled = loadImage("combo_disabled.png");
    private static final BufferedImage combo_edit_btn = loadImage("combo_edit_btn.png");
    private static final BufferedImage combo_edit_btn_over = loadImage("combo_edit_btn_over.png");
    private static final BufferedImage combo_edit_btn_pressed = loadImage("combo_edit_btn_pressed.png");
    private static Dimension BTN_SIZE = new Dimension(17, 20);
    private Dimension btnSize = new Dimension(BTN_SIZE);

    /**
     * Creates a new UI deligate for the given component. It is a standard method that all UI deligates must have.
     *
     * @param c The component that the UI is for
     * @return a new instance of NimbusComboBoxUI
     */
    public static ComponentUI createUI(JComponent c) {
        return new NimbusComboBoxUI();
    }


    @Override public void installUI(JComponent c) {
        super.installUI(c);
        c.setOpaque(false);
    }

    @Override protected void installListeners() {
        super.installListeners();
        comboBox.addMouseListener(this);
    }


    @Override protected void uninstallListeners() {
        super.uninstallListeners();
        comboBox.removeMouseListener(this);
    }

    /** The minumum size is the size of the display area plus insets plus the button. */
    public Dimension getMinimumSize(JComponent c) {
        if (!isMinimumSizeDirty) {
            return new Dimension(cachedMinimumSize);
        }
        Dimension size = getDisplaySize();
        Insets insets = getInsets();
        btnSize.height = size.height = Math.max(size.height, BTN_SIZE.height);
        btnSize.width = (int) ((double) (BTN_SIZE.width / (double) BTN_SIZE.height) * btnSize.height);
        size.height += insets.top + insets.bottom;
        size.width += insets.left + insets.right + btnSize.width;

        cachedMinimumSize.setSize(size.width, size.height);
        isMinimumSizeDirty = false;

        return new Dimension(size);
    }

    protected JButton createArrowButton() {
        JButton button = new JButton() {
            @Override protected void paintComponent(Graphics g) {
                if (comboBox.isEditable()) {
                    BufferedImage img = combo_edit_btn;
                    if (mouseDown) {
                        img = combo_edit_btn_pressed;
                    } else if (!comboBox.isEnabled()) {
                        img = combo_edit_btn;
                    } else if (mouseInside) {
                        img = combo_edit_btn_over;
                    }
                    g.drawImage(img,
                            0, 0, getWidth(), getHeight(),
                            0, 0, img.getWidth(), img.getHeight(), comboBox);
                }
            }
        };
        button.addMouseListener(this);
        button.setMinimumSize(BTN_SIZE);
        button.setPreferredSize(BTN_SIZE);
        button.setMargin(new Insets(0, 0, 0, 0));
        return button;
    }

    public void paint(Graphics g, JComponent c) {
        hasFocus = comboBox.hasFocus();
        ListCellRenderer renderer = comboBox.getRenderer();
        Rectangle r = new Rectangle(0, 0, comboBox.getWidth(), comboBox.getHeight());
        paintCurrentValueBackground(g, r, hasFocus);
        if (!comboBox.isEditable()) {
            if (renderer instanceof JComponent) {
                ((JComponent) renderer).setOpaque(false);
                ((JComponent) renderer).setForeground(comboBox.getForeground());
            }
            paintCurrentValue(g, rectangleForCurrentValue(), false);
            if (renderer instanceof JComponent) ((JComponent) renderer).setOpaque(true);
        }
    }

    @Override public void paintCurrentValueBackground(Graphics g, Rectangle bounds, boolean hasFocus) {
        if (!comboBox.isEditable()) {
            BufferedImage img = combo_normal;
            if (!comboBox.isEnabled()) {
                img = combo_disabled;
            } else if (mouseDown) {
                img = combo_pressed;
            } else if (mouseInside) {
                img = combo_over;
            }
            g.drawImage(img,
                    bounds.x, bounds.y, bounds.x + 4, bounds.y + bounds.height ,
                    0, 0, 4, 20, comboBox);
            g.drawImage(img,
                    bounds.x + 4, bounds.y, bounds.x + bounds.width - 17, bounds.y + bounds.height ,
                    5, 0, 6, 20, comboBox);
            g.drawImage(img,
                    bounds.x + bounds.width - 17, bounds.y, bounds.x + bounds.width , bounds.y + bounds.height ,
                    7, 0, 24, 20, comboBox);
        } else {
            g.setColor(Color.WHITE);
            g.fillRect(bounds.x, bounds.y, bounds.width - btnSize.width, bounds.height - 1);
            int x = bounds.x, y = bounds.y, w = bounds.width - btnSize.width, h = bounds.height - 1;
            Insets insets = getInsets();
            g.setColor(new Color(141, 142, 143));
            g.drawLine(x, y, x + insets.left, y);
            g.setColor(new Color(203, 203, 204));
            g.drawLine(x + 1, y + 1, x + insets.left, y + 1);
            g.setColor(new Color(152, 152, 153));
            g.drawLine(x, y + 1, x, y + 1);
            g.setColor(new Color(242, 242, 242));
            g.drawLine(x + 1, y + 2, x + insets.left, y + 2);
            g.setColor(new Color(176, 176, 177));
            g.drawLine(x, y + 2, x, y + 2);
            g.setColor(new Color(192, 192, 193));
            g.drawLine(x, y + h, x + insets.left, y + h);
            g.setColor(new Color(184, 184, 185));
            g.drawLine(x, y + 3, x, y + h);
            }
    }

    protected LayoutManager createLayoutManager() {
        return new ComboLayout();
    }


    @Override protected Insets getInsets() {
        return new Insets(0, 5, 0, 0);
    }

    // =================================================================================================================
    // MouseListener Methods

    private boolean mouseInside = false;
    private boolean mouseDown = false;

    public void mouseClicked(MouseEvent e) {}

    public void mouseEntered(MouseEvent e) {
        if (comboBox.isEditable()) {
            if (e.getComponent() == arrowButton) mouseInside = true;
        } else {
            mouseInside = true;
            comboBox.repaint();
        }
    }

    public void mouseExited(MouseEvent e) {
        if (comboBox.isEditable()) {
            if (e.getComponent() == arrowButton) mouseInside = false;
        } else {
            mouseInside = false;
            comboBox.repaint();
        }
    }

    public void mousePressed(MouseEvent e) {
        if (comboBox.isEditable()) {
            if (e.getComponent() == arrowButton) mouseDown = true;
        } else {
            mouseDown = true;
            comboBox.repaint();
        }
    }

    public void mouseReleased(MouseEvent e) {
        if (comboBox.isEditable()) {
            if (e.getComponent() == arrowButton) mouseDown = false;
        } else {
            mouseDown = false;
            comboBox.repaint();
        }
    }

    // =================================================================================================================
    // LayoutManager

    private class ComboLayout implements LayoutManager {
        public void addLayoutComponent(String name, Component comp) {}

        public void removeLayoutComponent(Component comp) {}

        public Dimension preferredLayoutSize(Container parent) {
            return parent.getPreferredSize();
        }

        public Dimension minimumLayoutSize(Container parent) {
            return parent.getMinimumSize();
        }

        public void layoutContainer(Container parent) {
            JComboBox cb = (JComboBox) parent;
            int width = cb.getWidth();

            Insets insets = getInsets();
            Rectangle cvb;

            if (arrowButton != null) {
                if (cb.getComponentOrientation().isLeftToRight()) {
                    arrowButton.setBounds(width - (insets.right + btnSize.width),
                            insets.top,
                            btnSize.width, btnSize.height);
                } else {
                    arrowButton.setBounds(insets.left, insets.top,
                            btnSize.width, btnSize.height);
                }
            }
            if (editor != null) {
                cvb = rectangleForCurrentValue();
                editor.setBounds(cvb.x, cvb.y, cvb.width, cvb.height);
            }
        }

    }

}
