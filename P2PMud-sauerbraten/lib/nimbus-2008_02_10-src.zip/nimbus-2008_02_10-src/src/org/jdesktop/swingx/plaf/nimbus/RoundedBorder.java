/*
* $Id: NimbusGraphicsUtils.java,v 1.9 2005/12/05 15:00:55 kizune Exp $
*
* Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
* Santa Clara, California 95054, U.S.A. All rights reserved.
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
package org.jdesktop.swingx.plaf.nimbus;

import static org.jdesktop.swingx.plaf.nimbus.NimbusGraphicsUtils.loadImage;

import javax.swing.border.Border;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

/**
 * RoundedBorder - A border implementation that draws a inner shadowed receced border with rounded corners. It also
 * darkens the center contents by about 5-10%.
 *
 * @author Created by Jasper Potts (Jan 18, 2007)
 * @version 1.0
 */
public class RoundedBorder implements Border {

    private static final BufferedImage img = loadImage("border.png");
    private static final Insets SPACE_INSETS = new Insets(25, 5, 5, 5);
    private static final Insets INSETS = new Insets(
            SPACE_INSETS.top + 0,
            SPACE_INSETS.left + 12,
            SPACE_INSETS.bottom + 12,
            SPACE_INSETS.right + 12);

    /** {@inheritDoc} */
    public Insets getBorderInsets(Component c) {
        return INSETS;
    }

    /** {@inheritDoc} */
    public boolean isBorderOpaque() {
        return false;
    }

    /** {@inheritDoc} */
    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        ((Graphics2D) g).setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        Rectangle b = new Rectangle(
                x + SPACE_INSETS.left,
                y + SPACE_INSETS.top,
                width - (SPACE_INSETS.left + SPACE_INSETS.right + 1),
                height - (SPACE_INSETS.top + SPACE_INSETS.bottom + 1));
        //top
        g.drawImage(img,
                b.x, b.y, b.x + 10, b.y + 10,
                0, 0, 10, 10, null);
        g.drawImage(img,
                b.x + 10, b.y, b.x + b.width - 10, b.y + 10,
                11, 0, 12, 10, null);
        g.drawImage(img,
                b.x + b.width - 10, b.y, b.x + b.width, b.y + 10,
                22, 0, 32, 10, null);
        // bottom
        g.drawImage(img,
                b.x, b.y + b.height - 10, b.x + 10, b.y + b.height,
                0, 22, 10, 32, null);
        g.drawImage(img,
                b.x + 10, b.y + b.height - 10, b.x + b.width - 10, b.y + b.height,
                11, 22, 12, 32, null);
        g.drawImage(img,
                b.x + b.width - 10, b.y + b.height - 10, b.x + b.width, b.y + b.height,
                22, 22, 32, 32, null);
        // left
        g.drawImage(img,
                b.x, b.y + 10, b.x + 10, b.y + b.height - 10,
                0, 11, 10, 12, null);
        // right
        g.drawImage(img,
                b.x + b.width - 10, b.y + 10, b.x + b.width, b.y + b.height - 10,
                22, 11, 32, 12, null);
        // fill
        g.drawImage(img,
                b.x + 10, b.y + 10, b.x + b.width - 10, b.y + b.height - 10,
                15, 15, 16, 16, null);


    }
}
