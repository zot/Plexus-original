/*
* $Id: NimbusGraphicsUtils.java,v 1.9 2005/12/05 15:00:55 kizune Exp $
*
* Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
* Santa Clara, California 95054, U.S.A. All rights reserved.
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
package org.jdesktop.swingx.plaf.nimbus.painters;

import static org.jdesktop.swingx.plaf.nimbus.NimbusGraphicsUtils.loadImage;

import javax.swing.SwingConstants;
import javax.swing.JSplitPane;
import javax.swing.plaf.synth.SynthContext;
import javax.swing.plaf.synth.SynthPainter;
import java.awt.image.BufferedImage;
import java.awt.Color;
import java.awt.Graphics;

/**
 * TextFieldPainter
 *
 * @author Created by Jasper Potts (Jan 4, 2007)
 * @version 1.0
 */
public class SplitPanePainter extends SynthPainter {

    private boolean fill = true;
    private static final BufferedImage vert_img = loadImage("split_pane_vertical.png");
    private static final BufferedImage horz_img = loadImage("split_pane_horizontal.png");
    
    public SplitPanePainter() {}

    public SplitPanePainter(boolean fill) {
        this.fill = fill;
    }

    
        /** {@inheritDoc} */
    @Override public void   paintSplitPaneBackground(SynthContext context, Graphics g, int x, int y, int w, int h) {
     //     Paints the background of a split pane.
    }
    /** {@inheritDoc} */
    @Override public void paintSplitPaneBorder(SynthContext context, Graphics g, int x, int y, int w, int h) {
    //      Paints the border of a split pane.
    }
    /** {@inheritDoc} */
    @Override public void paintSplitPaneDividerBackground(SynthContext context, Graphics g, int x, int y, int w, int h) {
    //      Paints the background of the divider of a split pane.
    }

    /** {@inheritDoc} */
    @Override public void paintSplitPaneDividerBackground(SynthContext context, Graphics g, int x, int y, int w, int h, int orientation) {
        // Paints the background of the divider of a split pane.
        //System.out.println("paintSplitPaneDividerBackground");
        w--;
        h--;
        if (fill) {
            g.setColor(new Color(0xd6, 0xd9, 0xdf));
            g.fillRect(x, y, w, h);
        }
        JSplitPane splitPane = ((JSplitPane) context.getComponent()); 
                
        if (orientation == SwingConstants.HORIZONTAL) {
            System.out.println("VERTICAL");
            System.out.println(w);
            //top line
            g.setColor(new Color(0xef, 0xf0, 0xf2));
            g.drawLine(x, y, x + w, y);
            
            //bottom line
            g.setColor(new Color(0xe6, 0xe8, 0xec));
            g.drawLine(x, y + h, x + w, y + h);
            g.drawImage(vert_img, (w - vert_img.getWidth())/2, y+2, vert_img.getWidth(), vert_img.getHeight(), splitPane);
        }  
        else {
            //System.out.println(w);
            //left line
            g.setColor(new Color(0xef, 0xf0, 0xf2));
            g.drawLine(x, y, x, y + h);
            
            //right line
            g.setColor(new Color(0xe6, 0xe8, 0xec));
            g.drawLine(x + w, y, x + w, y + h);
            g.drawImage(horz_img, x+2, (h - horz_img.getHeight())/2, horz_img.getWidth(), horz_img.getHeight(), splitPane);
        }
    }
    
    /** {@inheritDoc} */
    @Override public void paintSplitPaneDividerForeground(SynthContext context, Graphics g, int x, int y, int w, int h, int orientation) {
    //      Paints the foreground of the divider of a split pane.
    }
    /** {@inheritDoc} */
    @Override public void paintSplitPaneDragDivider(SynthContext context, Graphics g, int x, int y, int w, int h, int orientation) {
    //      Paints the divider, when the user is dragging the divider, of a split pane.
         paintSplitPaneDividerBackground(context, g, x, y, w, h, orientation);
    }
}
