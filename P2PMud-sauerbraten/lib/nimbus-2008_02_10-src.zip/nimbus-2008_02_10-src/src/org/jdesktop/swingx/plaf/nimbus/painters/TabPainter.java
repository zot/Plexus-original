/*
* $Id: NimbusGraphicsUtils.java,v 1.9 2005/12/05 15:00:55 kizune Exp $
*
* Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
* Santa Clara, California 95054, U.S.A. All rights reserved.
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
package org.jdesktop.swingx.plaf.nimbus.painters;

import org.jdesktop.swingx.plaf.nimbus.NimbusGraphicsUtils;

import javax.swing.SwingConstants;
import javax.swing.plaf.synth.SynthConstants;
import javax.swing.plaf.synth.SynthContext;
import javax.swing.plaf.synth.SynthPainter;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.LinearGradientPaint;
import java.awt.RenderingHints;

/**
 * TabPainter
 *
 * @author Created by Jasper Potts (Jan 4, 2007)
 * @version 1.0
 */
public class TabPainter extends SynthPainter {

    /** {@inheritDoc} */
    @Override public void paintTabbedPaneBackground(SynthContext context, Graphics g, int x, int y, int w, int h) {
        g.setColor(NimbusGraphicsUtils.getWebColor("d6d9df"));
        g.fillRect(x, y, w, h);
    }

    /** {@inheritDoc} */
    @Override public void paintTabbedPaneBorder(SynthContext context, Graphics g, int x, int y, int w, int h) {
    }

    /** {@inheritDoc} */
    @Override public void paintTabbedPaneContentBackground(SynthContext context, Graphics g, int x, int y, int w,
                                                           int h) {
    }

    /** {@inheritDoc} */
    @Override public void paintTabbedPaneContentBorder(SynthContext context, Graphics g, int x, int y, int w, int h) {
//        g.setColor(Color.BLUE);
//        g.drawRect(x,y,w-1,h-1);
    }

    private boolean isMouseOver = false;
    private boolean isOldMouseOver = false;

    /** {@inheritDoc} */
    @Override public void paintTabbedPaneTabAreaBackground(SynthContext context, Graphics g, int x, int y, int w, int h,
                                                           int orientation) {
        g.setColor(NimbusGraphicsUtils.getWebColor("d6d9df"));
        g.fillRect(x, y, w, h);
        Color one, two, three;
        one = NimbusGraphicsUtils.getWebColor("B5CADD");
        two = NimbusGraphicsUtils.getWebColor("BBD0E3");
        three = NimbusGraphicsUtils.getWebColor("C0D5E8");
//        if (isMouseOver){
//        if ((context.getComponentState() & SynthConstants.MOUSE_OVER) != 0
//                && (context.getComponentState() & SynthConstants.SELECTED) != 0) {
//            one = getWebColor("c8ddf0");
//            two = getWebColor("cee3f6");
//            three = getWebColor("d3e8fb");
//        } else if ((context.getComponentState() & SynthConstants.FOCUSED) != 0
//                && (context.getComponentState() & SynthConstants.SELECTED) != 0) {
//            one = getWebColor("406f99");
//            two = getWebColor("4776a0");
//            three = getWebColor("4b7aa4");
//        } else {
//            one = getWebColor("B5CADD");
//            two = getWebColor("BBD0E3");
//            three = getWebColor("C0D5E8");
//        }
        switch (orientation) {
            case SwingConstants.TOP:
                g.setColor(NimbusGraphicsUtils.getWebColor("000012"));
                g.drawLine(x, y + h - 5, x + w, y + h - 5);
                g.drawLine(x, y + h - 1, x + w, y + h - 1);
                g.setColor(one);
                g.drawLine(x, y + h - 4, x + w, y + h - 4);
                g.setColor(two);
                g.drawLine(x, y + h - 3, x + w, y + h - 3);
                g.setColor(three);
                g.drawLine(x, y + h - 2, x + w, y + h - 2);
                break;
            case SwingConstants.BOTTOM:
                g.setColor(NimbusGraphicsUtils.getWebColor("000012"));
                g.drawLine(x, y, x + w, y);
                g.drawLine(x, y + 4, x + w, y + 4);
                g.setColor(one);
                g.drawLine(x, y + 3, x + w, y + 4);
                g.setColor(two);
                g.drawLine(x, y + 2, x + w, y + 2);
                g.setColor(three);
                g.drawLine(x, y + 1, x + w, y + 1);
                break;
            case SwingConstants.LEFT:
                g.setColor(NimbusGraphicsUtils.getWebColor("000012"));
                g.drawLine(x + w - 1, y, x + w - 1, y + h);
                g.drawLine(x + w - 5, y, x + w - 5, y + h);
                g.setColor(one);
                g.drawLine(x + w - 4, y, x + w - 4, y + h);
                g.setColor(two);
                g.drawLine(x + w - 3, y, x + w - 3, y + h);
                g.setColor(three);
                g.drawLine(x + w - 2, y, x + w - 2, y + h);
                break;
            case SwingConstants.RIGHT:
                break;
        }
//        System.out.print("(");
//        if ((context.getComponentState() & SynthConstants.MOUSE_OVER) != 0) System.out.print("MOUSE_OVER ");
//        if ((context.getComponentState() & SynthConstants.DEFAULT) != 0) System.out.print("DEFAULT ");
//        if ((context.getComponentState() & SynthConstants.DISABLED) != 0) System.out.print("DISABLED ");
//        if ((context.getComponentState() & SynthConstants.FOCUSED) != 0) System.out.print("FOCUSED ");
//        if ((context.getComponentState() & SynthConstants.PRESSED) != 0) System.out.print("PRESSED ");
//        if ((context.getComponentState() & SynthConstants.SELECTED) != 0) System.out.print("SELECTED ");
//        System.out.println(")");
    }

    /** {@inheritDoc} */
    @Override public void paintTabbedPaneTabAreaBorder(SynthContext context, Graphics g, int x, int y, int w, int h,
                                                       int orientation) {
//        g.setColor(Color.ORANGE);
//        g.drawRect(x,y,w,h);
    }

    /** {@inheritDoc} */
    @Override public void paintTabbedPaneTabBackground(SynthContext context, Graphics g, int x, int y, int w, int h,
                                                       int tabIndex, int orientation) {
        // hacky trick to paint tab area brackgound with mouse over effects
//        if ((context.getComponentState() & SynthConstants.MOUSE_OVER) != 0
//                && (context.getComponentState() & SynthConstants.SELECTED) != 0) {
//            isMouseOver = true;
//        } else if ((context.getComponentState() & SynthConstants.SELECTED) != 0) {
//            isMouseOver = false;
//        }
//        if (isOldMouseOver != isMouseOver){
//            isOldMouseOver = isMouseOver;
//            context.getComponent().repaint();
//            return;
//        }
        // paint tab
        Graphics2D g2 = (Graphics2D) g
                .create(x, y, w, h + (((context.getComponentState() & SynthConstants.SELECTED) != 0) ? 1 : 0));
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
//        if ((context.getComponentState() & SynthConstants.MOUSE_OVER) != 0
//                && (context.getComponentState() & SynthConstants.SELECTED) != 0) {
//            g2.setPaint(new LinearGradientPaint(0, 0, 0, h,
//                    new float[]{0, 0.8f, 0.85f, 1},
//                    new Color[]{
//                            getWebColor("8fa9c0"),
//                            getWebColor("33628c"),
//                            getWebColor("33628c"),
//                            getWebColor("3c6a95")
//                    }));
//        } else
        if ((context.getComponentState() & SynthConstants.SELECTED) != 0) {
            g2.setPaint(new LinearGradientPaint(0, 0, 0, h,
                    new float[]{0, 0.8f, 0.85f, 1},
                    new Color[]{
                            NimbusGraphicsUtils.getWebColor("f2f5f7"),
                            NimbusGraphicsUtils.getWebColor("a3b8cb"),
                            NimbusGraphicsUtils.getWebColor("a3b8cb"),
                            NimbusGraphicsUtils.getWebColor("aec3d6")
                    }));
        } else if ((context.getComponentState() & SynthConstants.MOUSE_OVER) != 0) {
            g2.setPaint(new LinearGradientPaint(0, 0, 0, h,
                    new float[]{0, 0.7f, 1},
                    new Color[]{
                            NimbusGraphicsUtils.getWebColor("fbfcfc"),
                            NimbusGraphicsUtils.getWebColor("e9ecf2"),
                            NimbusGraphicsUtils.getWebColor("e9ecf2")
                    }));
        } else {
            g2.setPaint(new LinearGradientPaint(0, 0, 0, h,
                    new float[]{0, 0.7f, 1},
                    new Color[]{
                            NimbusGraphicsUtils.getWebColor("fbfbfc"),
                            NimbusGraphicsUtils.getWebColor("d6d9df"),
                            NimbusGraphicsUtils.getWebColor("d6d9df")
                    }));
        }
        g2.fillRoundRect(4, 0, w - 8, h + 10, 10, 10);

    }

    /** {@inheritDoc} */
    @Override public void paintTabbedPaneTabBorder(SynthContext context, Graphics g, int x, int y, int w, int h,
                                                   int tabIndex, int orientation) {
        Graphics2D g2 = (Graphics2D) g
                .create(x, y, w, h + (((context.getComponentState() & SynthConstants.SELECTED) != 0) ? 1 : 0));
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(NimbusGraphicsUtils.getWebColor("00000C"));
        g2.drawRoundRect(4, 0, w - 8, h + 10, 10, 10);
    }
}
