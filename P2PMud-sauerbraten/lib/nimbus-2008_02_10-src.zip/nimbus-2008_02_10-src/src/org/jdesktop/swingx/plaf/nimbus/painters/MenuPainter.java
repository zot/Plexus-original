/*
* $Id: NimbusGraphicsUtils.java,v 1.9 2005/12/05 15:00:55 kizune Exp $
*
* Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
* Santa Clara, California 95054, U.S.A. All rights reserved.
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
package org.jdesktop.swingx.plaf.nimbus.painters;

import org.jdesktop.swingx.plaf.nimbus.NimbusGraphicsUtils;
import static org.jdesktop.swingx.plaf.nimbus.NimbusGraphicsUtils.getWebColor;

import javax.swing.plaf.synth.SynthConstants;
import javax.swing.plaf.synth.SynthContext;
import javax.swing.plaf.synth.SynthPainter;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.LinearGradientPaint;

/**
 * MenuPainter
 *
 * @author Created by Jasper Potts (Jan 4, 2007)
 * @version 1.0
 */
public class MenuPainter extends SynthPainter {

    /** {@inheritDoc} */
    @Override public void paintMenuBarBackground(SynthContext context, Graphics g, int x, int y, int w, int h) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setPaint(new LinearGradientPaint(x, y, x, y + h,
                new float[]{0, 0.8f, 1},
                new Color[]{
                        NimbusGraphicsUtils.getWebColor("f9fafb"),
                        NimbusGraphicsUtils.getWebColor("d6d9df"),
                        NimbusGraphicsUtils.getWebColor("d6d9df")
                }));
        g2.fillRect(x, y, w, h);
    }

    /** {@inheritDoc} */
    @Override public void paintMenuBarBorder(SynthContext context, Graphics g, int x, int y, int w, int h) {
        g.setColor(NimbusGraphicsUtils.getWebColor("9297a1"));
        g.drawLine(x, y + h - 1, x + w, y + h - 1);
    }

    /** {@inheritDoc} */
    @Override public void paintPopupMenuBackground(SynthContext context, Graphics g, int x, int y, int w, int h) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setPaint(new GradientPaint(0, y + 1, Color.white, 0, y + 6, NimbusGraphicsUtils.getWebColor("edeff2")));
        g.fillRect(x, y + 1, w, y + h - 7);
        g2.setPaint(
                new GradientPaint(0, y + h - 2, Color.white, 0, y + h - 7, NimbusGraphicsUtils.getWebColor("edeff2")));
        g.fillRect(x, y + h - 7, w, y + h - 2);
    }

    /** {@inheritDoc} */
    @Override public void paintPopupMenuBorder(SynthContext context, Graphics g, int x, int y, int w, int h) {
        g.setColor(NimbusGraphicsUtils.getWebColor("595959"));
        g.drawRect(x, y, w - 1, h - 1);
        g.setColor(new Color(128, 128, 128, 80));
        g.drawLine(x + 1, y + 3, x + 1, y + h - 3);
        g.drawLine(x + w - 2, y + 3, x + w - 2, y + h - 3);
    }

    /** {@inheritDoc} */
    @Override public void paintMenuBackground(SynthContext context, Graphics g, int x, int y, int w, int h) {
        if ((context.getComponentState() & SynthConstants.SELECTED) != 0) {
            g.setColor(NimbusGraphicsUtils.getWebColor("3A698A"));
            g.fillRect(x, y, w, h);
        }
    }

    /** {@inheritDoc} */
    @Override public void paintSeparatorForeground(SynthContext context, Graphics g, int x, int y, int w, int h,
                                                   int orientation) {
        g.setColor(getWebColor("B9BBBD"));
        g.drawLine(x,y+2,x+w,y+2);
    }
}
