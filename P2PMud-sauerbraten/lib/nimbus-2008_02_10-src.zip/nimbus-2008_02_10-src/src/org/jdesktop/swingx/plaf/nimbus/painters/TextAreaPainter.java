/*
* $Id: NimbusGraphicsUtils.java,v 1.9 2005/12/05 15:00:55 kizune Exp $
*
* Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
* Santa Clara, California 95054, U.S.A. All rights reserved.
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
package org.jdesktop.swingx.plaf.nimbus.painters;

import javax.swing.plaf.synth.SynthContext;
import javax.swing.plaf.synth.SynthPainter;
import java.awt.Color;
import java.awt.Graphics;

/**
 * TextFieldPainter
 *
 * @author Created by Jasper Potts (Jan 4, 2007)
 * @version 1.0
 */
public class TextAreaPainter extends SynthPainter {

    private boolean fill = true;

    public TextAreaPainter() {}

    public TextAreaPainter(boolean fill) {
        this.fill = fill;
    }

    /** {@inheritDoc} */
    @Override public void paintTextAreaBackground(SynthContext context, Graphics g, int x, int y, int w, int h) {
        w--;
        h--;
        if (fill) {
            g.setColor(Color.WHITE);
            g.fillRect(x, y, w, h);
        }
        //first top line  140 142 140
        g.setColor(new Color(141, 142, 143));
        g.drawLine(x, y, x + w, y);
        //second top line
        g.setColor(new Color(203, 203, 204));
        g.drawLine(x + 1, y + 1, x + w - 1, y + 1);
        g.setColor(new Color(152, 152, 153));
        g.drawLine(x, y + 1, x, y + 1);
        g.drawLine(x + w, y + 1, x + w, y + 1);
        g.setColor(new Color(242, 242, 242));
        g.drawLine(x + 1, y + 2, x + w - 2, y + 2);
        g.setColor(new Color(176, 176, 177));
        g.drawLine(x, y + 2, x, y + 2);
        g.drawLine(x + w, y + 2, x + w, y + 2);
        g.setColor(new Color(184, 184, 185));
        g.drawLine(x, y + 3, x, y + h);
        g.drawLine(x + w, y + 3, x + w, y + h);
        g.drawLine(x, y + h, x + w, y + h);
    }
}
