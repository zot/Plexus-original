/*
* $Id: NimbusGraphicsUtils.java,v 1.9 2005/12/05 15:00:55 kizune Exp $
*
* Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
* Santa Clara, California 95054, U.S.A. All rights reserved.
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
package org.jdesktop.swingx.plaf.nimbus.painters;

import org.jdesktop.swingx.plaf.nimbus.NimbusGraphicsUtils;
import static org.jdesktop.swingx.plaf.nimbus.NimbusGraphicsUtils.loadImage;

import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.plaf.synth.SynthConstants;
import javax.swing.plaf.synth.SynthContext;
import javax.swing.plaf.synth.SynthPainter;
import java.awt.Color;
import java.awt.Container;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

/**
 * InternalFramePainter
 *
 * @author Created by Jasper Potts (Jan 4, 2007)
 * @version 1.0
 */
public class InternalFramePainter extends SynthPainter {

    private static final BufferedImage FRAME_IMG = loadImage("inner_frame.png");
    private static final BufferedImage FRAME_IMG_NONFOCUSED = loadImage("inner_frame_defocused.png");
    private static final BufferedImage FRAME_CLOSE_DULL = loadImage("frame_close_dull.png");
    private static final BufferedImage FRAME_CLOSE = loadImage("frame_close.png");
    private static final BufferedImage FRAME_CLOSE_OVER = loadImage("frame_close_over.png");
    private static final BufferedImage FRAME_CLOSE_PRESSED = loadImage("frame_close_pressed.png");
    private static final BufferedImage FRAME_MAXIMIZE_DULL = loadImage("frame_maximize_dull.png");
    private static final BufferedImage FRAME_MAXIMIZE = loadImage("frame_maximize.png");
    private static final BufferedImage FRAME_MAXIMIZE_OVER = loadImage("frame_maximize_over.png");
    private static final BufferedImage FRAME_MAXIMIZE_PRESSED = loadImage("frame_maximize_pressed.png");
    private static final BufferedImage FRAME_MENU_BTN_DULL = loadImage("frame_menu_btn_dull.png");
    private static final BufferedImage FRAME_MENU_BTN = loadImage("frame_menu_btn.png");
    private static final BufferedImage FRAME_MENU_BTN_OVER = loadImage("frame_menu_btn_over.png");
    private static final BufferedImage FRAME_MENU_BTN_PRESSED = loadImage("frame_menu_btn_pressed.png");
    private static final BufferedImage FRAME_MINIMIZE_DULL = loadImage("frame_minimize_dull.png");
    private static final BufferedImage FRAME_MINIMIZE = loadImage("frame_minimize.png");
    private static final BufferedImage FRAME_MINIMIZE_OVER = loadImage("frame_minimize_over.png");
    private static final BufferedImage FRAME_MINIMIZE_PRESSED = loadImage("frame_minimize_pressed.png");
    private static final BufferedImage FRAME_WINDOWIZE_DULL = loadImage("frame_windowize_dull.png");
    private static final BufferedImage FRAME_WINDOWIZE = loadImage("frame_windowize.png");
    private static final BufferedImage FRAME_WINDOWIZE_OVER = loadImage("frame_windowize_over.png");
    private static final BufferedImage FRAME_WINDOWIZE_PRESSED = loadImage("frame_windowize_pressed.png");


    /** {@inheritDoc} */
    @Override public void paintDesktopPaneBackground(SynthContext context, Graphics g, int x, int y, int w, int h) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setPaint(new GradientPaint(x, y, NimbusGraphicsUtils.getWebColor("476f8f"), x, y + h,
                NimbusGraphicsUtils.getWebColor("2b4960")));
        g2.fillRect(x, y, w, h);
    }


    /** {@inheritDoc} */
    @Override public void paintDesktopPaneBorder(SynthContext context, Graphics g, int x, int y, int w, int h) {

    }

    /** {@inheritDoc} */
    @Override public void paintInternalFrameBackground(SynthContext context, Graphics g, int x, int y, int w, int h) {
        g.setColor(NimbusGraphicsUtils.getWebColor("EBEDF2"));
        g.fillRect(x + 1, y + 1, w - 2, h - 2);
    }

    /** {@inheritDoc} */
    @Override public void paintInternalFrameBorder(SynthContext context, Graphics g, int x, int y, int w, int h) {
        BufferedImage img;
        Color frameColor;
        if (((JInternalFrame) context.getComponent()).isSelected()) {
            img = FRAME_IMG;
            frameColor = NimbusGraphicsUtils.getWebColor("2b2e33");
        } else {
            img = FRAME_IMG_NONFOCUSED;
            frameColor = NimbusGraphicsUtils.getWebColor("525761");
        }
        // outer frame
        g.setColor(frameColor);
        g.drawLine(x, y + 1, x, h - 2);
        g.drawLine(x + w - 1, y + 1, x + w - 1, h - 2);
        g.drawLine(x + 1, y, x + w - 2, y);
        g.drawLine(x + 1, y + h - 1, x + w - 2, y + h - 1);
        // left
        g.drawImage(img, x + 1, y + 1, x + 6, y + 25,
                0, 0, 5, 24, null);
        g.drawImage(img, x + 1, y + 25, x + 6, y + h - 6,
                0, 25, 5, 26, null);
        g.drawImage(img, x + 1, y + h - 6, x + 6, y + h - 1,
                0, 25, 5, 29, null);
        // bottom
        g.drawImage(img, x + 6, y + h - 6, x + w - 6, y + h - 1,
                6, 25, 7, 29, null);
        // right
        g.drawImage(img, x + w - 6, y + 1, x + w, y + 25,
                6, 0, 12, 24, null);
        g.drawImage(img, x + w - 6, y + 25, x + w, y + h - 6,
                6, 25, 12, 26, null);
        g.drawImage(img, x + w - 6, y + h - 6, x + w, y + h - 1,
                6, 25, 12, 29, null);
    }

    /** {@inheritDoc} */
    @Override public void paintInternalFrameTitlePaneBackground(SynthContext context, Graphics g, int x, int y, int w,
                                                                int h) {
        BufferedImage img;
        if ((context.getComponentState() & SynthConstants.SELECTED) != 0) {
            img = FRAME_IMG;
        } else {
            img = FRAME_IMG_NONFOCUSED;
        }
        g.drawImage(img, x, y, x + w, y + 24,
                6, 0, 7, 24, null);
    }

    /** {@inheritDoc} */
    @Override public void paintInternalFrameTitlePaneBorder(SynthContext context, Graphics g, int x, int y, int w,
                                                            int h) {
    }


    /** {@inheritDoc} */
    @Override public void paintButtonBackground(SynthContext context, Graphics g, int x, int y, int w, int h) {
        JButton button = (JButton) context.getComponent();
        if ("InternalFrameTitlePane.menuButton".equals(button.getName())) {
            if (isNotSelected(button)) {
                g.drawImage(FRAME_MENU_BTN_DULL, x, y, button);
            } else if ((context.getComponentState() & SynthConstants.PRESSED) != 0) {
                g.drawImage(FRAME_MENU_BTN_PRESSED, x, y, button);
            } else if ((context.getComponentState() & SynthConstants.MOUSE_OVER) != 0) {
                g.drawImage(FRAME_MENU_BTN_OVER, x, y, button);
            } else {
                g.drawImage(FRAME_MENU_BTN, x, y, button);
            }
        } else if ("InternalFrameTitlePane.iconifyButton".equals(button.getName())) {
            if (isNotSelected(button)) {
                g.drawImage(FRAME_MAXIMIZE_DULL, x, y, button);
            } else if ((context.getComponentState() & SynthConstants.PRESSED) != 0) {
                g.drawImage(FRAME_MINIMIZE_PRESSED, x, y, button);
            } else if ((context.getComponentState() & SynthConstants.MOUSE_OVER) != 0) {
                g.drawImage(FRAME_MINIMIZE_OVER, x, y, button);
            } else {
                g.drawImage(FRAME_MINIMIZE, x, y, button);
            }
        } else if ("InternalFrameTitlePane.maximizeButton".equals(button.getName())) {
            if (isMaximized(button)) {
                if (isNotSelected(button)) {
                    g.drawImage(FRAME_WINDOWIZE_DULL, x, y, button);
                } else if ((context.getComponentState() & SynthConstants.PRESSED) != 0) {
                    g.drawImage(FRAME_WINDOWIZE_PRESSED, x, y, button);
                } else if ((context.getComponentState() & SynthConstants.MOUSE_OVER) != 0) {
                    g.drawImage(FRAME_WINDOWIZE_OVER, x, y, button);
                } else {
                    g.drawImage(FRAME_WINDOWIZE, x, y, button);
                }
            } else {
                if (isNotSelected(button)) {
                    g.drawImage(FRAME_MAXIMIZE_DULL, x, y, button);
                } else if ((context.getComponentState() & SynthConstants.PRESSED) != 0) {
                    g.drawImage(FRAME_MAXIMIZE_PRESSED, x, y, button);
                } else if ((context.getComponentState() & SynthConstants.MOUSE_OVER) != 0) {
                    g.drawImage(FRAME_MAXIMIZE_OVER, x, y, button);
                } else {
                    g.drawImage(FRAME_MAXIMIZE, x, y, button);
                }
            }
        } else if ("InternalFrameTitlePane.closeButton".equals(button.getName())) {
            if (isNotSelected(button)) {
                g.drawImage(FRAME_CLOSE_DULL, x, y, button);
            } else if ((context.getComponentState() & SynthConstants.PRESSED) != 0) {
                g.drawImage(FRAME_CLOSE_PRESSED, x, y, button);
            } else if ((context.getComponentState() & SynthConstants.MOUSE_OVER) != 0) {
                g.drawImage(FRAME_CLOSE_OVER, x, y, button);
            } else {
                g.drawImage(FRAME_CLOSE, x, y, button);
            }
        }
    }

    /**
     * Helper method to find out if the inner frame for a given control button is maximized.
     *
     * @param btn A button that is in the innerframe
     * @return <code>true</code> if btn is in a innerframe and that frame is maximimized.
     */
    private static boolean isMaximized(JButton btn) {
        for (Container p = btn.getParent(); p != null; p = p.getParent()) {
            if (p instanceof JInternalFrame) {
                return ((JInternalFrame) p).isMaximum();
            }
        }
        return false;
    }

    /**
     * Helper method to find out if the inner frame for a given control button is not selected(not to front).
     *
     * @param btn A button that is in the innerframe
     * @return <code>true</code> if btn is in a innerframe and that frame is not selected.
     */
    private static boolean isNotSelected(JButton btn) {
        for (Container p = btn.getParent(); p != null; p = p.getParent()) {
            if (p instanceof JInternalFrame) {
                return !((JInternalFrame) p).isSelected();
            }
        }
        return true;
    }
}
