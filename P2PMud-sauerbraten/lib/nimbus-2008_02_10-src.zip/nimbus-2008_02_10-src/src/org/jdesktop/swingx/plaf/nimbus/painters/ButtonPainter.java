/*
* $Id: NimbusGraphicsUtils.java,v 1.9 2005/12/05 15:00:55 kizune Exp $
*
* Copyright 2004 Sun Microsystems, Inc., 4150 Network Circle,
* Santa Clara, California 95054, U.S.A. All rights reserved.
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
package org.jdesktop.swingx.plaf.nimbus.painters;

import org.jdesktop.swingx.plaf.nimbus.NimbusGraphicsUtils;

import javax.swing.plaf.synth.SynthConstants;
import javax.swing.plaf.synth.SynthContext;
import javax.swing.plaf.synth.SynthPainter;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.LinearGradientPaint;
import java.awt.RenderingHints;


/**
 * ButtonPainter - handles painting Nimbus style buttons with Java2D
 *
 * @author Created by Jasper Potts (Jan 4, 2007)
 * @version 1.0
 */
public class ButtonPainter extends SynthPainter {

    private static final Color[] NORMAL_BG = new Color[]{
            NimbusGraphicsUtils.getWebColor("FBFBFC"),
            NimbusGraphicsUtils.getMidWebColor("FBFBFC", "F1F2F4"),
            NimbusGraphicsUtils.getWebColor("F1F2F4"),
            NimbusGraphicsUtils.getMidWebColor("FBFBFC", "D6D9DF"),
            NimbusGraphicsUtils.getWebColor("D6D9DF"),
            NimbusGraphicsUtils.getWebColor("D6D9DF"),
            NimbusGraphicsUtils.getMidWebColor("D6D9DF", "F4F7FD"),
            NimbusGraphicsUtils.getWebColor("F4F7FD"),
            NimbusGraphicsUtils.getWebColor("FFFFFF")
    };
    private static final Color[] NORMAL_FG = new Color[]{
            NimbusGraphicsUtils.getWebColor("95989E"),
            NimbusGraphicsUtils.getWebColor("95989E"),
            NimbusGraphicsUtils.getWebColor("55585E"),
            NimbusGraphicsUtils.getWebColor("55585E")
    };
    private static final Color[] PRELIGHT_BG = new Color[]{
            NimbusGraphicsUtils.getWebColor("FDFDFE"),
            NimbusGraphicsUtils.getMidWebColor("FDFDFE", "F7F8FA"),
            NimbusGraphicsUtils.getWebColor("F7F8FA"),
            NimbusGraphicsUtils.getMidWebColor("F7F8FA", "E9ECF2"),
            NimbusGraphicsUtils.getWebColor("E9ECF2"),
            NimbusGraphicsUtils.getWebColor("E9ECF2"),
            NimbusGraphicsUtils.getMidWebColor("E9ECF2", "FFFFFF"),
            NimbusGraphicsUtils.getWebColor("FFFFFF"),
            NimbusGraphicsUtils.getWebColor("FFFFFF")
    };
    private static final Color[] PRELIGHT_FG = new Color[]{
            NimbusGraphicsUtils.getWebColor("7A7E86"),
            NimbusGraphicsUtils.getWebColor("7A7E86"),
            NimbusGraphicsUtils.getWebColor("2A2E36"),
            NimbusGraphicsUtils.getWebColor("2A2E36")
    };
    private static final Color[] ACTIVE_BG = new Color[]{
            NimbusGraphicsUtils.getWebColor("CDD1D8"),
            NimbusGraphicsUtils.getMidWebColor("CDD1D8", "C2C7CF"),
            NimbusGraphicsUtils.getWebColor("C2C7CF"),
            NimbusGraphicsUtils.getMidWebColor("C2C7CF", "A4ABB8"),
            NimbusGraphicsUtils.getWebColor("A4ABB8"),
            NimbusGraphicsUtils.getWebColor("A4ABB8"),
            NimbusGraphicsUtils.getMidWebColor("A4ABB8", "CCD3E0"),
            NimbusGraphicsUtils.getWebColor("CCD3E0"),
            NimbusGraphicsUtils.getWebColor("E7EDFB")
    };
    private static final Color[] ACTIVE_FG = new Color[]{
            NimbusGraphicsUtils.getWebColor("000007"),
            NimbusGraphicsUtils.getWebColor("000007"),
            NimbusGraphicsUtils.getWebColor("60646C"),
            NimbusGraphicsUtils.getWebColor("60646C")
    };

    private static final Color[] DEFAULT_NORMAL_BG = new Color[]{
            NimbusGraphicsUtils.getWebColor("F6F8FA"),
            NimbusGraphicsUtils.getMidWebColor("F6F8FA", "DFE6ED"),
            NimbusGraphicsUtils.getWebColor("DFE6ED"),
            NimbusGraphicsUtils.getMidWebColor("DFE6ED", "A3B8CB"),
            NimbusGraphicsUtils.getWebColor("A3B8CB"),
            NimbusGraphicsUtils.getWebColor("A3B8CB"),
            NimbusGraphicsUtils.getMidWebColor("A3B8CB", "C1D6E9"),
            NimbusGraphicsUtils.getWebColor("C1D6E9"),
            NimbusGraphicsUtils.getWebColor("D5EAFD")
    };
    private static final Color[] DEFAULT_NORMAL_FG = new Color[]{
            NimbusGraphicsUtils.getWebColor("62778A"),
            NimbusGraphicsUtils.getWebColor("62778A"),
            NimbusGraphicsUtils.getWebColor("22374A"),
            NimbusGraphicsUtils.getWebColor("22374A")
    };
    private static final Color[] DEFAULT_PRELIGHT_BG = new Color[]{
            NimbusGraphicsUtils.getWebColor("F8FAFC"),
            NimbusGraphicsUtils.getMidWebColor("F8FAFC", "E6EDF3"),
            NimbusGraphicsUtils.getWebColor("E6EDF3"),
            NimbusGraphicsUtils.getMidWebColor("E6EDF3", "B6C8DE"),
            NimbusGraphicsUtils.getWebColor("B6C8DE"),
            NimbusGraphicsUtils.getWebColor("B6C8DE"),
            NimbusGraphicsUtils.getMidWebColor("B6C8DE", "D4E9FC"),
            NimbusGraphicsUtils.getWebColor("D4E9FC"),
            NimbusGraphicsUtils.getWebColor("E8FDFF")
    };
    private static final Color[] DEFAULT_PRELIGHT_FG = new Color[]{
            NimbusGraphicsUtils.getWebColor("3B556D"),
            NimbusGraphicsUtils.getWebColor("3B556D"),
            NimbusGraphicsUtils.getWebColor("00051D"),
            NimbusGraphicsUtils.getWebColor("00051D")
    };
    private static final Color[] DEFAULT_ACTIVE_BG = new Color[]{
            NimbusGraphicsUtils.getWebColor("8FA9C0"),
            NimbusGraphicsUtils.getMidWebColor("8FA9C0", "7695B2"),
            NimbusGraphicsUtils.getWebColor("7695B2"),
            NimbusGraphicsUtils.getMidWebColor("7695B2", "33628C"),
            NimbusGraphicsUtils.getWebColor("33628C"),
            NimbusGraphicsUtils.getWebColor("33628C"),
            NimbusGraphicsUtils.getMidWebColor("33628C", "5B89B4"),
            NimbusGraphicsUtils.getWebColor("5B89B4"),
            NimbusGraphicsUtils.getWebColor("76A4CE")
    };
    private static final Color[] DEFAULT_ACTIVE_FG = new Color[]{
            NimbusGraphicsUtils.getWebColor("000000"),
            NimbusGraphicsUtils.getWebColor("000000"),
            NimbusGraphicsUtils.getWebColor("1C3851"),
            NimbusGraphicsUtils.getWebColor("1C3851")
    };

    private static final Color[] DISABLED_BG = new Color[]{
            NimbusGraphicsUtils.getWebColor("E3EFE9"),
            NimbusGraphicsUtils.getMidWebColor("E3EFE9", "DFE2E6"),
            NimbusGraphicsUtils.getWebColor("DFE2E6"),
            NimbusGraphicsUtils.getMidWebColor("DFE2E6", "D6D9DF"),
            NimbusGraphicsUtils.getWebColor("D6D9DF"),
            NimbusGraphicsUtils.getWebColor("D6D9DF"),
            NimbusGraphicsUtils.getMidWebColor("D6D9DF", "D8DBE1"),
            NimbusGraphicsUtils.getWebColor("D8DBE1"),
            NimbusGraphicsUtils.getWebColor("DADDE3")
    };
    private static final Color[] DISABLED_FG = new Color[]{
            NimbusGraphicsUtils.getWebColor("C9CCD2"),
            NimbusGraphicsUtils.getWebColor("C9CCD2"),
            NimbusGraphicsUtils.getWebColor("BCBFC5"),
            NimbusGraphicsUtils.getWebColor("BCBFC5")
    };


    /** {@inheritDoc} */
    @Override public void paintButtonBackground(SynthContext context, Graphics g, int x, int y, int w, int h) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        Color[] fg, bg;
        if ((context.getComponentState() & SynthConstants.DEFAULT) != 0){
            if ((context.getComponentState() & SynthConstants.PRESSED) != 0) {
                fg = DEFAULT_ACTIVE_FG;
                bg = DEFAULT_ACTIVE_BG;
            } else if ((context.getComponentState() & SynthConstants.DISABLED) != 0) {
                fg = DISABLED_FG;
                bg = DISABLED_BG;
            } else if ((context.getComponentState() & SynthConstants.MOUSE_OVER) != 0) {
                fg = DEFAULT_PRELIGHT_FG;
                bg = DEFAULT_PRELIGHT_BG;
            } else {
                fg = DEFAULT_NORMAL_FG;
                bg = DEFAULT_NORMAL_BG;
            }
        } else {
            if ((context.getComponentState() & SynthConstants.PRESSED) != 0) {
                fg = ACTIVE_FG;
                bg = ACTIVE_BG;
            } else if ((context.getComponentState() & SynthConstants.DISABLED) != 0) {
                fg = DISABLED_FG;
                bg = DISABLED_BG;
            } else if ((context.getComponentState() & SynthConstants.MOUSE_OVER) != 0) {
                fg = PRELIGHT_FG;
                bg = PRELIGHT_BG;
            } else {
                fg = NORMAL_FG;
                bg = NORMAL_BG;
            }
        }
        w = w-2;
        h = h-2;
        if ((context.getComponentState() & SynthConstants.DISABLED) == 0) {
            g2.setPaint(NORMAL_FG[0].brighter());
            g2.drawRoundRect(x + 1, y + 1, w, h, h / 3, h / 3);
        }

        g2.setPaint(new LinearGradientPaint(x, y, x, y + h,
                new float[]{0, 0.024f, 0.06f, 0.276f, 0.6f, 0.7f, 0.856f, 0.9f, 1}, bg));
        g2.fillRoundRect(x, y, w, h, h / 3, h / 3);


        g2.setPaint(new LinearGradientPaint(x, y, x, y + h,
                new float[]{0, 0.05f, 0.95f, 1}, fg));
        g2.drawRoundRect(x, y, w, h, h / 3, h / 3);
    }
}
