/*
* $Id: FocusPainter.java,v 1.1 2007/03/13 15:00:55 pottsj Exp $
*
* Copyright 2007 Sun Microsystems, Inc., 4150 Network Circle,
* Santa Clara, California 95054, U.S.A. All rights reserved.
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
package org.jdesktop.swingx.plaf.nimbus;

import javax.swing.*;
import javax.swing.plaf.basic.BasicSliderUI;
import javax.swing.plaf.basic.BasicTabbedPaneUI;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.image.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

/**
 * On construction, registers itself with the current keyboard focus manager as a propery change listener
 * attached to the "focusOwner" property.
 *
 * @author Created by Jasper Potts (Mar 15, 2007)
 * @author Ben Galbraith
 * @version 1.0
 */
public class FocusPainter implements PropertyChangeListener {
//    private static final Color FOCUS_COLOR = new Color(255,164,62);
    //    private static final Color FOCUS_COLOR = new Color(167, 198, 218);
    private static final Color FOCUS_COLOR = new Color(103, 173, 218);
    private static final int BLUR_SIZE = 9;
    private static final float BLUR_SPREAD = 0.15f;
    private static final double BLUR_OPACITY = 0.6;

    private KeyboardFocusManager focusManager;
    private Map<Window, FocusComponent> focusComponentMap = new HashMap<Window, FocusComponent>();

    public FocusPainter() {
        focusManager = KeyboardFocusManager.getCurrentKeyboardFocusManager();
        focusManager.addPropertyChangeListener("focusOwner", this);
    }

    /**
     * Paints the focus outline around the currently focused component in response to
     * changes to the "focusOwner" property of the current KeyboardFocusManager.
     *
     * @param evt
     */
    public void propertyChange(PropertyChangeEvent evt) {
        System.out.println("evt.getPropertyName() = " + evt.getPropertyName() + " = " + evt.getNewValue());
        if (evt.getNewValue() != null) {
            // a new component has received focus; get the window corresponding to the component
            // in order to install a FocusComponent in it
            Window activeWindow = focusManager.getActiveWindow();

            // install a FocusComponent in the window's layered pane (or retrieve the instance already installed)
            FocusComponent focusComponent = getFocusComponent(activeWindow);

            if (focusComponent != null) {
                // tell the FocusComponent to paint the focus outline
                focusComponent.setCurrentlyFocusedComponent(focusManager.getFocusOwner());
            }
        }
    }

    private FocusComponent getFocusComponent(Window window) {
        FocusComponent focusComponent = focusComponentMap.get(window);
        if (focusComponent == null) {
            if (window instanceof JFrame) {
                JLayeredPane layeredPane = ((JFrame) window).getLayeredPane();
                focusComponent = new FocusComponent(layeredPane);
                layeredPane.add(focusComponent, new Integer(250));
            } else if (window instanceof JDialog) {
                JLayeredPane layeredPane = ((JDialog) window).getLayeredPane();
                focusComponent = new FocusComponent(layeredPane);
                layeredPane.add(focusComponent, new Integer(250));
            }
            focusComponentMap.put(window, focusComponent);
        }
        System.out.println("FocusPainter.getFocusComponent(" + window.hashCode() + ") => " + focusComponent.hashCode());
        return focusComponent;
    }

    /**
     * Occupies the entire bounds of the JLayeredPane and paints a focus glow effect within itself just above
     * the component that has focus.
     */
    private static class FocusComponent extends JComponent {
        private Component currentlyFocusedComponent = null;

        private WeakReference<JComponent> lastFocusedComponent = new WeakReference<JComponent>(null);
        private BufferedImage lastFocusImage = null;
        private Dimension lastSize = null;

        public FocusComponent(final JLayeredPane layeredPane) {
            setBounds(0, 0, layeredPane.getWidth(), layeredPane.getHeight());
            // keep component filling whole layerpane
            layeredPane.addComponentListener(new ComponentAdapter() {
                @Override
                public void componentResized(ComponentEvent e) {
                    System.out.println("FocusPainter$FocusComponent.componentResized");
                    setBounds(0, 0, layeredPane.getWidth(), layeredPane.getHeight());
                }
            });
        }

        public void setCurrentlyFocusedComponent(Component currentlyFocusedComponent) {
            this.currentlyFocusedComponent = currentlyFocusedComponent;
            repaint();
        }


        @Override
        protected void paintComponent(Graphics g) {
            if (currentlyFocusedComponent != null && currentlyFocusedComponent instanceof JComponent) {
                JComponent component = (JComponent) currentlyFocusedComponent;
                Rectangle bounds = new Rectangle(0, 0, component.getSize().width, component.getSize().height);
                Dimension size = component.getSize();

                BufferedImage focusImg;
                if ((component == lastFocusedComponent.get()) && (size.equals(lastSize))) {
                    focusImg = lastFocusImage;
                } else {
                    focusImg = createFocusGlow(bounds, component, g);
                    lastFocusImage = focusImg;
                    lastSize = size;
                    lastFocusedComponent = new WeakReference<JComponent>(component);
                }

                // calculate the clip -- this helps prevents the glow effect from wrapping partially invisible components
                // by clipping the drawn glow from the entire component bounds down to the visible rect.
                // Because the clip needs to take into account the glow overflow from the visible rect (the blur size)
                // this gets a little messy.
                Rectangle rect = component.getVisibleRect();
                if (rect.width == bounds.width) rect.width += BLUR_SIZE;
                if (rect.height == bounds.height) rect.height += BLUR_SIZE;
                if (rect.x == bounds.x) {
                    rect.x -= BLUR_SIZE;
                    rect.width += BLUR_SIZE;
                }
                if (rect.y == bounds.y) {
                    rect.y -= BLUR_SIZE;
                    rect.height += BLUR_SIZE;
                }

                g = g.create();
                Rectangle clip = SwingUtilities.convertRectangle(component, rect, this);
                g.clipRect(clip.x, clip.y, clip.width, clip.height);
                bounds = SwingUtilities.convertRectangle(component, bounds, this);
                g.drawImage(focusImg, bounds.x - BLUR_SIZE - BLUR_SIZE, bounds.y - BLUR_SIZE - BLUR_SIZE, null);
                g.dispose();
            }
        }

        private BufferedImage createFocusGlow(Rectangle bounds, JComponent component, Graphics g) {
            BufferedImage img = NimbusGraphicsUtils.createCompatibleTranslucentImage(
                    bounds.width + BLUR_SIZE + BLUR_SIZE, bounds.height + BLUR_SIZE + BLUR_SIZE);
            Graphics imgG = img.createGraphics();
            Graphics componentG = imgG.create(BLUR_SIZE, BLUR_SIZE, bounds.width, bounds.height);
            componentG.setColor(Color.BLACK);

            if (component instanceof JRadioButton ||
                    component instanceof JCheckBox) {
                Color fg = component.getForeground();
                component.setForeground(new Color(0, 0, 0, 0));
                component.paint(componentG);
                component.setForeground(fg);
            } else if (component instanceof JTabbedPane) {
                JTabbedPane tabbedPane = (JTabbedPane) component;
                BasicTabbedPaneUI tabbedPaneUI = (BasicTabbedPaneUI) tabbedPane.getUI();
                Rectangle tabRect = tabbedPaneUI.getTabBounds(tabbedPane, tabbedPane.getSelectedIndex());
                componentG.fillRoundRect(tabRect.x + 4, tabRect.y, tabRect.width - 7, tabRect.height, 5, 5);
            } else if (component instanceof JSlider) {
                JSlider slider = (JSlider) component;
                BasicSliderUI basicSliderUI = (BasicSliderUI) slider.getUI();
                try {
                    Field thumbRectField = BasicSliderUI.class.getDeclaredField("thumbRect");
                    thumbRectField.setAccessible(true);
                    Rectangle thumbRect = (Rectangle) thumbRectField.get(basicSliderUI);
                    componentG.fillOval(thumbRect.x, thumbRect.y, thumbRect.width, thumbRect.height);
                } catch (Exception e) {
                    e.printStackTrace();
                    g.fillRect(0, 0, bounds.width, bounds.height);
                }
            } else if (component instanceof JButton ||
                    component instanceof JToggleButton) {
                component.paint(componentG);
            } else {
                // generic just paint around the bounds
                componentG.setColor(Color.BLACK);
                componentG.fillRect(0, 0, bounds.width, bounds.height);
            }
            componentG.dispose();
            imgG.dispose();
            BufferedImage focusImg = createFocusedImage(img);
            return focusImg;
        }


        BufferedImage testImage;


        private BufferedImage createFocusedImage(BufferedImage srcImg) {
            int w = srcImg.getWidth() + (2 * BLUR_SIZE);
            int h = srcImg.getHeight() + (2 * BLUR_SIZE);
            // get alpha
            BufferedImage alpha = NimbusGraphicsUtils.getAlphaMask(srcImg, w, h);
            // create grey image buffers
            BufferedImage greyBuffer = new BufferedImage(w, h, BufferedImage.TYPE_BYTE_GRAY);
            BufferedImage outline = new BufferedImage(w, h, BufferedImage.TYPE_BYTE_GRAY);
            // outline blur
            Kernel[] outlineKernels = NimbusGraphicsUtils.getSeparateGaussianKernel(1);
            new ConvolveOp(outlineKernels[0]).filter(alpha, greyBuffer);
            new ConvolveOp(outlineKernels[1]).filter(greyBuffer, outline);
            // glow blur
            Kernel[] glowKernels = NimbusGraphicsUtils.getSeparateGaussianKernel(BLUR_SIZE);
            new ConvolveOp(glowKernels[0]).filter(alpha, greyBuffer);
            new ConvolveOp(glowKernels[1]).filter(greyBuffer, alpha);
            // merge two blur results to create mask
            byte[] outlineData = ((DataBufferByte) outline.getRaster().getDataBuffer()).getData();
            byte[] glowData = ((DataBufferByte) alpha.getRaster().getDataBuffer()).getData();
            for (int i = 0; i < glowData.length; i++) {
                glowData[i] = (outlineData[i] == 0) ? (byte) (glowData[i] * BLUR_OPACITY) : 0;
            }
            //rescale
            RescaleOp rescaleOp = new RescaleOp(1f / BLUR_SPREAD, 0f, null);
            rescaleOp.filter(alpha, alpha);
            // create dest image
            final BufferedImage dstImg = NimbusGraphicsUtils.createCompatibleTranslucentImage(w, h);
            Graphics2D g2 = dstImg.createGraphics();
            g2.drawImage(NimbusGraphicsUtils.createColorMaskImage(alpha, FOCUS_COLOR), 0, 0, null);
            g2.dispose();
            return dstImg;
        }

    }
}
