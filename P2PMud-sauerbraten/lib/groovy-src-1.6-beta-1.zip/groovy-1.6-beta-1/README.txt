$Id: README.txt 7092 2007-08-10 09:53:31Z user57 $

Building
========

To build you will need:

 * JDK 1.4+ (J2SE 1.4.0+) (http://java.sun.com/j2se/1.4.2)
 * Apache Ant 1.7+ (http://ant.apache.org)

For detailed instructions please see:

    http://groovy.codehaus.org/Building+Groovy+from+Source

To build everything, run tests and create a complete installation:

    ant install

To build without running tests:

    ant install -DskipTests=true

