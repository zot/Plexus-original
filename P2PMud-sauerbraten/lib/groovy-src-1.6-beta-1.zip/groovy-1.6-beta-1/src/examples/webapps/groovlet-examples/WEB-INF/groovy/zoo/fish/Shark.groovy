package zoo.fish

import zoo.Fish

class Shark extends Fish {

  String saySomething(String something) {
    return "Shark bites " + something + "...ROOOAR�!"
  }

}
